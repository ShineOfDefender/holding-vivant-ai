﻿# Architecture — Agroecological Decision Engine

Core data flow:

Plant database
↓
Ecological friction calculation
↓
Plant-site compatibility matrix
↓
Climate adjustment
↓
Strategic scoring
↓
Operational dashboards

Data sources:

• plant biological data
• site characteristics
• climate observations
• economic demand channels

Future ML layer:

Observations
↓
Training dataset
↓
Machine learning model
↓
Adaptive scoring
↓
Improved recommendations
