﻿# HOLDING VIVANT — Agroecological Decision Engine

Prototype of a data-driven system designed to optimize ecological agriculture.

The project integrates:

• plant biological databases  
• site characteristics  
• climate data  
• ecological friction modelling  
• commercial channel analysis  

Goal:
Create a decision engine able to recommend optimal crop placement
based on ecology, climate and economic demand.

Pipeline:

Plant database  
↓  
Friction calculation  
↓  
Plant–site matrices  
↓  
Climate adjustment  
↓  
Strategic ranking  
↓  
Operational dashboards  

Current status:

✔ plant database architecture  
✔ scoring pipeline  
✔ climate integration  
✔ operational cockpit  

Next step:

Integrate Machine Learning to improve predictions.

Technologies:

PowerShell  
Python  
CSV data pipelines  

Location:

Martinique (Caribbean)

Collaboration welcome.
