﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Jasmin (Jasminum sambac / Jasminum grandiflorum)

**Slug IA :** `jasmin`

**DisponibilitÃ© Martinique :** Bonne

**Famille :** Oleaceae

**Strates :** liane_florale

**Parties utilisÃ©es :** fleurs

**Formes :** dried, infusion, macerat

## Placement / rÃ´le
- LisiÃ¨re du manguier : treillis (air + lumiÃ¨re filtrÃ©e), Ã©viter humiditÃ© stagnante

## Tags (IA)
`olfactif` `memoire` `apaisant` `premium`

