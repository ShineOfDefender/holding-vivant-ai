﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Pomme dâ€™eau (Syzygium malaccense / Syzygium aqueum (selon variÃ©tÃ©))

**Slug IA :** `pomme_d_eau`

**DisponibilitÃ© Martinique :** Courant

**Famille :** Myrtaceae

**Strates :** canopy_fruitier

**Parties utilisÃ©es :** fruits

**Formes :** fresh

## Placement / rÃ´le
- Zone fraÃ®che mais drainÃ©e (Ã©viter cuvette inondable), proche brise-vent/haies

## Tags (IA)
`fruitier` `frais` `patrimoine`

