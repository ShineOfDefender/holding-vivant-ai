﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Roseau des Indes (Canna indica (souvent appelÃ© balisier / roseau des Indes))

**Slug IA :** `roseau_des_indes`

**DisponibilitÃ© Martinique :** TrÃ¨s courant

**Famille :** Cannaceae

**Strates :** zone_humide_tampon, ornement, bordure

**Parties utilisÃ©es :** rhizomes, tiges, fleurs

**Formes :** bordure, tampon_hydrique

**RÃ´le systÃ¨me :** Bordure/tampon hydrique + stabilisation douce + dÃ©cor utile.

## Placement / rÃ´le (jardin crÃ©ole)
- Bords de zones humides / fossÃ©s / limites de ruissellement
- En lisiÃ¨re pour filtrer lâ€™eau et stabiliser

## Notes
- Excellent en zones oÃ¹ lâ€™eau circule; documenter comportement sur tes parcelles.

## Tags (IA)
`tampon` `humide` `bordure` `biodiversite`

