﻿# Notes — Bois d’Inde (Pimenta racemosa)
- Observations terrain :
- Variétés locales :
- Sources / références :
