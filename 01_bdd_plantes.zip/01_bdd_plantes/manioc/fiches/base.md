﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Manioc (Manihot esculenta)

**Slug IA :** `manioc`

**DisponibilitÃ© Martinique :** Courant

**Famille :** Euphorbiaceae

**Strates :** culture_plein_soleil

**Parties utilisÃ©es :** racines

**Formes :** fresh, farine, semoule

**RÃ´le systÃ¨me :** RÃ©serve stratÃ©gique (amidon) + base transformation.

## Placement / rÃ´le (jardin crÃ©ole)
- Zone plein soleil, sol drainÃ©
- Rotation propre, Ã©viter zones inondables

## Transformation / produits
- Farine (process Ã  cadrer proprement)
- Semoule / galettes (recettes locales)

## Notes
- Documenter variÃ©tÃ©s et process (qualitÃ© + sÃ©curitÃ© alimentaire).

## Tags (IA)
`amidon` `plein_soleil` `reserve` `transfo`

