﻿# Fiche Base - pervenche_de_madagascar

Slug IA: pervenche_de_madagascar
Origine: Martinique (Ducos / HOLDING_VIVANT)
Statut: semis du jour / a completer

## Identite
- Nom commun:
- Nom botanique:
- Famille:
- Type: fleur / ornement / pollinisateur

## Placement (Ducos)
- Soleil:
- Sol:
- Zone:

## Observations
- date:
- parcelle:
- note:

## Tags (IA)
fleur ornement pollinisateurs semis_2026 pervenche_de_madagascar
