﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Gingembre (Zingiber officinale)

**Slug IA :** `gingembre`

**DisponibilitÃ© Martinique :** TrÃ¨s bonne

**Famille :** Zingiberaceae

**Strates :** sous_bois_racines

**Parties utilisÃ©es :** rhizomes

**Formes :** fresh, dried, powder

## Placement / rÃ´le
- Sous manguier arc externe : mi-ombre, sol frais mais drainÃ© (bloc racines)

## Tags (IA)
`racine` `cuisine` `volume` `sous_bois`

