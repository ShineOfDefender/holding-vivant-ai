﻿# Rungis — Pois bois

## Allée cible
Epicerie seche elargie

## Formats
- vrac pro
- conditionnement institutionnel

## Différenciation
- local
- traçable
- transformation maîtrisée
