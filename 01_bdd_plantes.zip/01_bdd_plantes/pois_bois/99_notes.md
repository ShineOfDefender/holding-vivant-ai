﻿# Notes — Pois bois
- Observations terrain :
- Variétés locales :
- Sources / références :
