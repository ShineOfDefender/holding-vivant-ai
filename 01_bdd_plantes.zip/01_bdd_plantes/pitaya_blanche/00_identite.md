﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — BDD plantes  
---

# pitaya blanche

## Catégorie
À préciser (structurante / fruitière / ornementale)

## Zones adaptées
- humide / saline / sèche (à préciser)

## Rôle principal
- structuration
- protection
- production
- symbolique

## Architecture recommandée
- strate haute / intermédiaire / basse
- associations recommandées

## Entretien
- arrosage
- taille
- protection

## Valorisation
- alimentaire / ornementale / institutionnelle

## Notes terrain
- observations
