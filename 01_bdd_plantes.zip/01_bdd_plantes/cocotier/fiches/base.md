﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Cocotier (Cocos nucifera)

**Slug IA :** `cocotier`

**DisponibilitÃ© Martinique :** TrÃ¨s courant

**Famille :** Arecaceae

**Strates :** canopy_palmier

**Parties utilisÃ©es :** noix, eau, fibre

**Formes :** fresh

## Placement / rÃ´le
- Alignement pÃ©riphÃ©rique : brise-vent + structure verticale

## Tags (IA)
`brise_vent` `structure` `littoral`

