﻿# Vivriers & plantes structurantes

- Manioc
- Gombo
- Fruit à pain
- Bananiers :
  - Makandia
  - Gros plantain
  - Petit plantain
