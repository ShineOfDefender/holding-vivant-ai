﻿# Arbres & arbustes à épices

## Clou de girofle
- Rôle sol : arbre structurant
- Usage : épice sèche
- Zone : humide / intermédiaire

## Bois d’Inde
- Rôle sol : arbre aromatique
- Usage : épice / feuille
- Zone : intermédiaire

## Neem
- Rôle sol : protection biologique
- Usage : sol / cosmétique / agricole
- Zone : sèche / intermédiaire

## Moringa
- Rôle sol : enrichissement
- Usage : alimentaire / sol
- Zone : sèche / intermédiaire

## Vanillier
- Rôle sol : liane productive
- Usage : vanille transformée
- Zone : humide
