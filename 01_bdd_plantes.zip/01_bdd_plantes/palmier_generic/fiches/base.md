﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Palmier (gÃ©nÃ©rique) (Arecaceae (Ã  prÃ©ciser espÃ¨ce))

**Slug IA :** `palmier_generic`

**DisponibilitÃ© Martinique :** Courant

**Famille :** Arecaceae

**Strates :** canopy_palmier

**Parties utilisÃ©es :** structure

**Formes :** n/a

## Placement / rÃ´le
- PÃ©riphÃ©rie / lignes structurantes; utile en brise-vent et signal visuel

## Notes
- Ã€ prÃ©ciser espÃ¨ce locale si besoin (photo/nom).

## Tags (IA)
`structure` `brise_vent` `verticalite`

