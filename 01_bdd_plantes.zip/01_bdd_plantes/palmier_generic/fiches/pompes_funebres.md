﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche POMPES_FUNEBRES â€” Palmier (gÃ©nÃ©rique)

_Ã€ complÃ©ter (canal non dÃ©fini pour cette plante)._ 

