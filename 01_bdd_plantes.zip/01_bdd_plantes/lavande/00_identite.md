﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — BDD plantes  
---

# lavande

## Statut
Production expérimentale calme

## Zones adaptées
- zones sèches
- morne
- sol drainant

## Rôle
- aromatique
- apaisant
- observation agronomique

## Priorité
Faible (hors socle économique)

## Notes terrain
-
