﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Pandan (Pandanus amaryllifolius)

**Slug IA :** `pandan`

**DisponibilitÃ© Martinique :** Bonne

**Famille :** Pandanaceae

**Strates :** sous_bois_aromatique

**Parties utilisÃ©es :** feuilles

**Formes :** dried, fresh

## Placement / rÃ´le
- ArriÃ¨re-plan du quart de cercle sous manguier (mi-ombre stable), sol drainÃ©

## Tags (IA)
`aromatique` `memoire` `niche` `douceur`

