﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” VÃ©tiver (Vetiveria (Chrysopogon) zizanioides)

**Slug IA :** `vetiver`

**DisponibilitÃ© Martinique :** Moyenne Ã  bonne

**Famille :** Poaceae

**Strates :** anti_erosion

**Parties utilisÃ©es :** racines

**Formes :** roots, dried, broyage

## Placement / rÃ´le
- Courbes de niveau / bordures externes / zones de ruissellement
- Autour des zones canne : stabilisation + filtre + anti-inondation

## Tags (IA)
`anti_inondation` `ancrage` `terre` `stockage_long`

## Ressources / Transformes (systeme)
Transformes recommandes:
- arc_pierres_frontiere

Notes:
- Paillage: collet degage, pas de couche humide epaisse
- Eviter zones d'arbres a latex comme noyau productif

