﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” CaÃ¯mite (Chrysophyllum cainito)

**Slug IA :** `caimite`

**DisponibilitÃ© Martinique :** Courant

**Famille :** Sapotaceae

**Strates :** canopy_fruitier

**Parties utilisÃ©es :** fruits

**Formes :** fresh

## Placement / rÃ´le
- CanopÃ©e : arbre de structure sur dÃ©cennies, zone stable, large emprise racinaire

## Tags (IA)
`fruitier` `patrimoine` `long_terme`

