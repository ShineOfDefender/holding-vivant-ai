﻿# Sol & entretien — Neem (Azadirachta indica)

## Rôle sol
- Arbre structurant (long terme)
- Microclimat local (ombrage, humidité)

## Entretien
- Taille : à préciser
- Arrosage : à préciser selon zone
- Protection : paillage / couvre-sol

## Techniques douces
- Infusions sol (moringa/neem) : selon compatibilité et tests
