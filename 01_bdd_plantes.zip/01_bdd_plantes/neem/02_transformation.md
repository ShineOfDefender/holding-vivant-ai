﻿# Transformation — Neem (Azadirachta indica)

## Produits possibles
- Épice sèche (vrac)
- Feuilles sèches (si applicable)
- Poudre (si applicable, broyage contrôlé)
- Mélanges secs (épicerie sèche élargie)

## Procédés (principes)
- Séchage doux
- Stockage sec
- Traçabilité par lot

## Rejets valorisés
- Résidus végétaux → compost / paillage
