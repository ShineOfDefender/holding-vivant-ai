﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
Fruitiers structurants du jardin créole :
- Goyavier de Cayenne
- Carambolier
- Bananier (Makandia, gros plantain, petit plantain)

Rôle :
- Autonomie alimentaire
- Transformation
- Valeur patrimoniale

