﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Moringa (Moringa oleifera)

**Slug IA :** `moringa`

**DisponibilitÃ© Martinique :** Bon potentiel

**Famille :** Moringaceae

**Strates :** arbre_moyen, haie

**Parties utilisÃ©es :** feuilles

**Formes :** dried, powder

**RÃ´le systÃ¨me :** Feuille Ã  haute valeur: poudre (qualitÃ© + traÃ§abilitÃ©).

## Placement / rÃ´le (jardin crÃ©ole)
- Zone ensoleillÃ©e/mi-ombre, haies productives
- Proche sÃ©chage contrÃ´lÃ© (anti-perte)

## Transformation / produits
- SÃ©chage doux (ombre ventilÃ©e) â†’ broyage â†’ poudre
- MÃ©langes poudre type â€˜ayurvÃ©diqueâ€™ (Ã  documenter comme recettes)

## Recettes / usages (Ã  documenter)
- MÃ©lange poudre â€˜daliblÃ©â€™ (Ã  prÃ©ciser composition exacte)
- MÃ©langes thÃ©s/infusions (si utilisÃ©)

## Tags (IA)
`poudre` `ayurvedique` `feuille` `valeur`

