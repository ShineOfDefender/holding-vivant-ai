﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Manguier (Mangifera indica)

**Slug IA :** `manguier`

**DisponibilitÃ© Martinique :** TrÃ¨s courant

**Famille :** Anacardiaceae

**Strates :** canopy_fruitier

**Parties utilisÃ©es :** fruits

**Formes :** fresh

## Placement / rÃ´le
- Arbre-pilier : crÃ©e ombre claire pour aloÃ¨s/curcuma/gingembre/pandan
- Zone stable (Ã©viter cuvette inondable), prÃ©server le sol sous canopÃ©e

## Cultivars / Hybrides liÃ©s
- `mango_mouchasse` â€” Mangue mouchasse (hybride) (hybride_local)
  - Ã€ documenter : saison, taille/forme, goÃ»t, rendement, rÃ©sistance
  - Patrimoine : conserver via greffons / marcottes si pertinent

## Tags (IA)
`structure` `ombre` `centenaire` `microclimat`

