﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Bananier (variÃ©tÃ© 1) (Musa spp.)

**Slug IA :** `bananier_var1`

**DisponibilitÃ© Martinique :** TrÃ¨s courant

**Famille :** Musaceae

**Strates :** sous_canopy_humide

**Parties utilisÃ©es :** fruits

**Formes :** fresh

## Placement / rÃ´le
- Zone humide mais drainÃ©e, attention compÃ©tition eau/nutriments

## Tags (IA)
`humide` `rapide` `volume`

