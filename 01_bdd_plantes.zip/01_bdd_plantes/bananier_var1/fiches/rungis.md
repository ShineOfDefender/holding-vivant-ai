﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche RUNGIS â€” Bananier (variÃ©tÃ© 1)

_Ã€ complÃ©ter (canal non dÃ©fini pour cette plante)._ 

