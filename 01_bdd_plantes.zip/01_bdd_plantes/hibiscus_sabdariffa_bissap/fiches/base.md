﻿# Fiche Base - hibiscus_sabdariffa_bissap

Slug IA: hibiscus_sabdariffa_bissap
Origine: Martinique (Ducos / HOLDING_VIVANT)
Statut: semis du jour / a completer

## Identite
- Nom commun:
- Nom botanique:
- Famille:
- Type: fleur / ornement / pollinisateur

## Placement (Ducos)
- Soleil:
- Sol:
- Zone:

## Observations
- date:
- parcelle:
- note:

## Tags (IA)
fleur ornement pollinisateurs semis_2026 hibiscus_sabdariffa_bissap
