﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — BDD plantes  
---

# Cacaoyer

## Catégorie
arbre_fruiter

## Zones (Martinique)
- sèche / intermédiaire / humide / littorale (à préciser)

## Architecture jardin créole (rappel)
- Strate haute : fruitier structurant
- Sous-étage : aloe / couvre-sol selon zone
- Bordures : vétiver / légumineuses (selon objectif)

## Transformation
Transformation: poudre, infusion, nibs (plus tard)

## Rungis
Allée cible : Produits secs / transformation

## Notes terrain
- lat/lon zones prospères à renseigner dans la matrice
