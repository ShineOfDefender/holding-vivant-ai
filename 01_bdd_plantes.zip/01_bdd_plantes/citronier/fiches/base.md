﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Citronnier (Citrus limon)

**Slug IA :** `citronier`

**DisponibilitÃ© Martinique :** Courant

**Famille :** Rutaceae

**Strates :** arbre_moyen

**Parties utilisÃ©es :** fruits, zeste

**Formes :** fresh, dried

## Placement / rÃ´le
- Zone aÃ©rÃ©e, soleil, drainage; espacement avec gros arbres

## Tags (IA)
`agrumes` `polyvalent` `regularite`

