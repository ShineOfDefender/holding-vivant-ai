﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche RUNGIS â€” Citronnier

_Ã€ complÃ©ter (canal non dÃ©fini pour cette plante)._ 

