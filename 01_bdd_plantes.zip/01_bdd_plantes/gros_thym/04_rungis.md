﻿# Rungis — Gros thym

## Allée cible
Infusions feuilles entieres

## Formats
- vrac pro
- conditionnement institutionnel

## Différenciation
- local
- traçable
- transformation maîtrisée
