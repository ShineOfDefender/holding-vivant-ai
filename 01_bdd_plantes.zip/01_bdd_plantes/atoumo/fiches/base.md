﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Atoumo (Alpinia zerumbet)

**Slug IA :** `atoumo`

**DisponibilitÃ© Martinique :** TrÃ¨s courant

**Famille :** Zingiberaceae

**Strates :** sous_bois_aromatique

**Parties utilisÃ©es :** feuilles

**Formes :** dried, infusion

## Placement / rÃ´le
- Mi-ombre, bande infusion proche maison (rÃ©colte rapide), pas eau stagnante

## Tags (IA)
`the_pays` `infusion` `sous_bois` `patrimoine`

