﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Fruit Ã  pain (Artocarpus altilis)

**Slug IA :** `fruit_a_pain`

**DisponibilitÃ© Martinique :** Courant

**Famille :** Moraceae

**Strates :** canopy_fruitier

**Parties utilisÃ©es :** fruits

**Formes :** fresh, frozen, chips, farine

**RÃ´le systÃ¨me :** Pilier alimentaire + transformation (valeur ajoutÃ©e sans surproduction).

## Placement / rÃ´le (jardin crÃ©ole)
- Arbre de canopÃ©e: zone stable, bon sol, espace large
- Proche zone transformation (logistique)

## Transformation / produits
- Frites / chips (four ou friture)
- Farine (sÃ©chage + broyage)
- PrÃ©-cuisson + congÃ©lation (plus tard)

## Tags (IA)
`canopy` `amidon` `transformation` `chips`

