﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche EHPAD â€” Palmier royal

_Ã€ complÃ©ter (canal non dÃ©fini pour cette plante)._ 

