﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Palmier royal (Roystonea regia)

**Slug IA :** `palmier_royal`

**DisponibilitÃ© Martinique :** PrÃ©sent (ornemental)

**Famille :** Arecaceae

**Strates :** canopy_palmier

**Parties utilisÃ©es :** structure

**Formes :** n/a

## Placement / rÃ´le
- Alignement / entrÃ©e / bordure : marqueur patrimonial et esthÃ©tique sur siÃ¨cles

## Notes
- RÃ´le principal : architecture, pas productivitÃ© directe.

## Tags (IA)
`structure` `signal` `verticalite`

