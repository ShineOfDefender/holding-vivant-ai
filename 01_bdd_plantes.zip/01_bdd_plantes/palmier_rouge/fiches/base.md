﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Palmier rouge (Cyrtostachys renda (souvent appelÃ© palmier rouge))

**Slug IA :** `palmier_rouge`

**DisponibilitÃ© Martinique :** Ornemental (selon pÃ©piniÃ¨res)

**Famille :** Arecaceae

**Strates :** architecture, signal

**Parties utilisÃ©es :** structure

**Formes :** n/a

**RÃ´le systÃ¨me :** Marqueur patrimonial + esthÃ©tique; signal visuel (routes/entrÃ©es).

## Placement / rÃ´le (jardin crÃ©ole)
- EntrÃ©es / allÃ©es / zones visibles
- Ã‰viter zones trop sÃ¨ches si espÃ¨ce exigeante

## Notes
- RÃ´le principal: architecture, pas production.

## Tags (IA)
`signal` `esthetique` `alignement`

