﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Laitue (Lactuca sativa)

**Slug IA :** `laitue`

**DisponibilitÃ© Martinique :** Possible (selon chaleur/variÃ©tÃ©)

**Famille :** Asteraceae

**Strates :** potager_feuilles

**Parties utilisÃ©es :** feuilles

**Formes :** fresh

**RÃ´le systÃ¨me :** Potager frais (Ã  choisir variÃ©tÃ©s adaptÃ©es chaleur).

## Placement / rÃ´le (jardin crÃ©ole)
- Zone mi-ombre lÃ©gÃ¨re possible, arrosage rÃ©gulier, cycles courts

## Tags (IA)
`potager` `feuille` `rotation`

