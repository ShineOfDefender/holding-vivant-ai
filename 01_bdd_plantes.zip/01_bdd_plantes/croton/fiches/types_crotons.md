﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Types de crotons â€” base Ã  complÃ©ter

Objectif : documenter les variÃ©tÃ©s (couleur, rusticitÃ©, taille, usage en haie/ornement).

Champs Ã  noter :
- nom local / nom variÃ©tÃ©
- couleurs dominantes
- taille adulte
- vitesse de croissance
- tolÃ©rance soleil/ombre
- usage (haie, pot, massif)
- photos datÃ©es

