﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Croton (espace crotons) (Codiaeum variegatum)

**Slug IA :** `croton`

**DisponibilitÃ© Martinique :** TrÃ¨s courant (ornemental)

**Famille :** Euphorbiaceae

**Strates :** ornement_haie

**Parties utilisÃ©es :** feuillage

**Formes :** ornement, haie

**RÃ´le systÃ¨me :** Haies/espaces colorÃ©s (architecture, limites, esthÃ©tique).

## Placement / rÃ´le (jardin crÃ©ole)
- EntrÃ©es / bordures visibles / zones Ã  marquer
- CrÃ©er un â€˜jardin crotonâ€™ dÃ©diÃ© (collection variÃ©tale)

## Notes
- On documente les types/cultivars dans un fichier dÃ©diÃ©.

## Tags (IA)
`ornement` `haie` `signal`

