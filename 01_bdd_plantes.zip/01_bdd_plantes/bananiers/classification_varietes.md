﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
Classification des variétés :
- Makandia : luxe / patrimoine
- Gros plantain : alimentaire
- Petit plantain : alimentaire

