﻿# Florales & ornementales

- Zinnia
- Alpinia
- Hibiscus / Rose de Cayenne
- Rosier
- Bougainvillier
- Chrysanthème
- Ixora
