﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche EHPAD â€” Curcuma (safran pÃ©yi)

_Ã€ complÃ©ter (canal non dÃ©fini pour cette plante)._ 

