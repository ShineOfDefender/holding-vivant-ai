﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Curcuma (safran pÃ©yi) (Curcuma longa)

**Slug IA :** `curcuma`

**DisponibilitÃ© Martinique :** TrÃ¨s bonne

**Famille :** Zingiberaceae

**Strates :** sous_bois_racines

**Parties utilisÃ©es :** rhizomes

**Formes :** fresh, dried, powder

## Placement / rÃ´le
- Sous manguier arc mÃ©dian : plus frais que lâ€™aloÃ¨s (bloc racines)

## Tags (IA)
`racine` `poudre` `premium` `sous_bois`

