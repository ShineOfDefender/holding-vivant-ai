﻿# Notes — Pois d’Angole (Cajanus cajan)
- Observations terrain :
- Variétés locales :
- Sources / références :
