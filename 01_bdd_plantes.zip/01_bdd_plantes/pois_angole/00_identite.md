﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — BDD plantes  
---

# Pois d’Angole (Cajanus cajan)

## Catégorie
legumineuse_pois

## Rôles
- fixation azote / drainage / alimentation

## Parties utilisées
- À compléter

## Zones (Martinique)
- sèche / intermédiaire / humide / littorale (à préciser)

## Statut
Fiche structurée (v1)
