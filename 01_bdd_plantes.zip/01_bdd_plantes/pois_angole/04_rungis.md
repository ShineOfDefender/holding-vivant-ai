﻿# Rungis — Pois d’Angole (Cajanus cajan)

## Allée cible
Epicerie seche elargie

## Formats
- vrac pro
- conditionnement institutionnel

## Différenciation
- local
- traçable
- transformation maîtrisée
