﻿# Rungis — Chrysanthème

## Allée cible
Floral institutionnel

## Formats
- vrac pro
- conditionnement institutionnel

## Différenciation
- local
- traçable
- transformation maîtrisée
