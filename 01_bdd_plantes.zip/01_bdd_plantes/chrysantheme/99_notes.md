﻿# Notes — Chrysanthème
- Observations terrain :
- Variétés locales :
- Sources / références :
