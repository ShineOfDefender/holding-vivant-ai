﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Canne â€˜AOC hÃ©ritageâ€™ (conservatoire luxe) (Saccharum officinarum (variÃ©tÃ© locale Ã  conserver))

**Slug IA :** `canne_aoc_heritage`

**DisponibilitÃ© Martinique :** Ã€ relancer (conservatoire)

**Famille :** Poaceae

**Strates :** culture_plein_soleil

**Parties utilisÃ©es :** tiges

**Formes :** jus, sirop, micro_cuvee

## Placement / rÃ´le
- Plein soleil, parcelles surÃ©levÃ©es/banquettes + drainage
- Bandes vÃ©tiver + fossÃ©s de dÃ©rivation
- Cocotier/palmier : brise-vent et structure (si pertinent)

## Notes
- But : Ã©viter surproduction â†’ micro-lots millÃ©simÃ©s, qualitÃ© > volume
- Documenter : rendement, process, stockage, lot, millÃ©sime

## Tags (IA)
`luxe` `micro_lot` `heritage` `anti_inondation` `millÃ©sime`

