﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche RUNGIS â€” Canne â€˜AOC hÃ©ritageâ€™ (conservatoire luxe)

_Ã€ complÃ©ter (canal non dÃ©fini pour cette plante)._ 

