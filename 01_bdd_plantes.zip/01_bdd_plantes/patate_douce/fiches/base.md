﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Patate douce (Ipomoea batatas)

**Slug IA :** `patate_douce`

**DisponibilitÃ© Martinique :** Courant

**Famille :** Convolvulaceae

**Strates :** couvre_sol_productif

**Parties utilisÃ©es :** tubercules, feuilles

**Formes :** fresh, chips, farine

**RÃ´le systÃ¨me :** Couvre-sol + nourriture + transformation simple (valeur).

## Placement / rÃ´le (jardin crÃ©ole)
- Planches ensoleillÃ©es, bordures, zones Ã  couvrir contre lâ€™Ã©rosion
- TrÃ¨s bon en complÃ©ment des fruitiers (si lumiÃ¨re suffisante)

## Transformation / produits
- Frites / chips (marque premium, petites sÃ©ries)
- Farine (sÃ©chage + broyage) â€” plus tard

## Tags (IA)
`couvre_sol` `anti_erosion` `chips` `rotation`

