﻿# Notes — Zinnia
- Observations terrain :
- Variétés locales :
- Sources / références :
