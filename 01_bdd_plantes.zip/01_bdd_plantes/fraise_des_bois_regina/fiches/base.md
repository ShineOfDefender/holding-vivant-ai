﻿# Fiche Base - fraise_des_bois_regina

Slug IA: fraise_des_bois_regina
Origine: Martinique (Ducos / HOLDING_VIVANT)
Statut: semis du jour / a completer

## Identite
- Nom commun:
- Nom botanique:
- Famille:
- Type: fleur / ornement / pollinisateur

## Placement (Ducos)
- Soleil:
- Sol:
- Zone:

## Observations
- date:
- parcelle:
- note:

## Tags (IA)
fleur ornement pollinisateurs semis_2026 fraise_des_bois_regina
