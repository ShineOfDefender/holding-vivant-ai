﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Cassia alata (Senna alata (syn. Cassia alata))

**Slug IA :** `cassia_alata`

**DisponibilitÃ© Martinique :** Courant

**Famille :** Fabaceae

**Strates :** arbuste_moyen, bordure

**Parties utilisÃ©es :** feuilles, fleurs

**Formes :** dried, infusion

**RÃ´le systÃ¨me :** Arbuste de bordure Ã  usage traditionnel; stabilise les limites et la biodiversitÃ©.

## Placement / rÃ´le (jardin crÃ©ole)
- Bordures, haies, zones de transition
- Laisser aÃ©ration; Ã©viter trop dâ€™ombre dense

## Notes
- Ã€ documenter: usages locaux exacts + prÃ©cautions (institution).

## Tags (IA)
`arbuste` `bordure` `medicinal_trad`

