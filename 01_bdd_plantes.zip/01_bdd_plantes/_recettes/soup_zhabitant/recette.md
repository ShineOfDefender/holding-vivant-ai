﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Zoub zhabitant â€” recette (squelette)

## IngrÃ©dients
- 

## Ã‰tapes
1.

## Plantes/ lots utilisÃ©s
- herbe_couresse: 
- autres:

## Rendement / conservation
- 

## CoÃ»t / prix cible
- 

