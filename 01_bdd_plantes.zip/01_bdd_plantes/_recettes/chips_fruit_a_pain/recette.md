﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Chips / frites de fruit Ã  pain â€” recette (squelette)

## IngrÃ©dients
- fruit_a_pain

## Ã‰tapes
1.

## Rendement / conservation
- 

## CoÃ»t / prix cible
- 

