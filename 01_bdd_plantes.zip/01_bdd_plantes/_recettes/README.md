﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Recettes (base) â€” Ã  nourrir

Objectif : transformer le jardin crÃ©ole en catalogue monÃ©tisable sans surproduction.

## RÃ¨gle
- Une recette = un fichier
- Toujours : ingrÃ©dients, provenance (plantes/lot), Ã©tapes, rendement, conservation, coÃ»t, prix cible.

## Dossiers
- zoub_zhabitant/
- chips_patate_douce/
- chips_fruit_a_pain/
- melanges_poudres/
- thes_infusion/

