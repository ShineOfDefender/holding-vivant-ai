﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# MÃ©lange poudre â€˜daliblÃ©â€™ â€” base (Ã  prÃ©ciser)

## Objectif
MÃ©lange poudre inspirÃ© (moringa/curcuma/gingembreâ€¦ selon ta tradition).

## Composition (Ã  prÃ©ciser)
- moringa:
- curcuma:
- gingembre:
- autres:

## Process
- sÃ©chage doux
- broyage
- tamisage
- stockage

## Dosage / usage
- 

## TraÃ§abilitÃ© lots
- 

