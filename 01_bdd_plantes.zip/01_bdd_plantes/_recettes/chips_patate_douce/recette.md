﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Chips / frites de patate douce â€” recette (squelette)

## IngrÃ©dients
- patate_douce

## Ã‰tapes
1.

## Rendement / conservation
- 

## CoÃ»t / prix cible
- 

