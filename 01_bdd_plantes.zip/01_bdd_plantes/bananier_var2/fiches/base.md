﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Bananier (variÃ©tÃ© 2) (Musa spp.)

**Slug IA :** `bananier_var2`

**DisponibilitÃ© Martinique :** TrÃ¨s courant

**Famille :** Musaceae

**Strates :** sous_canopy_humide

**Parties utilisÃ©es :** fruits

**Formes :** fresh

## Placement / rÃ´le
- Zone humide mais drainÃ©e, espacer des agrumes

## Tags (IA)
`humide` `rapide` `volume`

