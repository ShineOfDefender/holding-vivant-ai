﻿# Rungis — Pois Congo

## Allée cible
Epicerie seche elargie

## Formats
- vrac pro
- conditionnement institutionnel

## Différenciation
- local
- traçable
- transformation maîtrisée
