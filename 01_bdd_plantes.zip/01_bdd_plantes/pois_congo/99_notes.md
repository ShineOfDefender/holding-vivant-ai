﻿# Notes — Pois Congo
- Observations terrain :
- Variétés locales :
- Sources / références :
