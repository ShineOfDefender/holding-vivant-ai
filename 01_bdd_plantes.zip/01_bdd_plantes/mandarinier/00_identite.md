﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — BDD plantes  
---

# Mandarinier

## Catégorie
arbre_fruiter

## Zones (Martinique)
- sèche / intermédiaire / humide / littorale (à préciser)

## Architecture jardin créole (rappel)
- Strate haute : fruitier structurant
- Sous-étage : aloe / couvre-sol selon zone
- Bordures : vétiver / légumineuses (selon objectif)

## Transformation
Agrume: frais + jus

## Rungis
Allée cible : Produits frais (chaine du froid potentielle)

## Notes terrain
- lat/lon zones prospères à renseigner dans la matrice
