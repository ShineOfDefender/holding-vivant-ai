﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Produits Ã  transformer â€” base

- thÃ©s/infusions (citronnelle, atoumo, pandan, mÃ©langes â€˜thÃ© paysâ€™)
- poudres (moringa, curcuma, gingembre) + mÃ©langes
- chips/frites (patate douce, fruit Ã  pain)
- farine (fruit Ã  pain, patate douce, manioc) â€” plus tard

