﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Herbe couresse (Cleome gynandra (souvent) â€” Ã  confirmer localement)

**Slug IA :** `herbe_couresse`

**DisponibilitÃ© Martinique :** TrÃ¨s courant (jardin crÃ©ole)

**Famille :** Cleomaceae

**Strates :** potager_feuilles

**Parties utilisÃ©es :** feuilles

**Formes :** fresh, cuit

**RÃ´le systÃ¨me :** Feuille patrimoniale (recettes), potager proche maison.

## Placement / rÃ´le (jardin crÃ©ole)
- CarrÃ©s potagers proches maison (accÃ¨s quotidien)
- Soleil/mi-ombre, arrosage lÃ©ger selon saison

## Recettes / usages (Ã  documenter)
- Zoub zhabitant (recette Ã  documenter)
- PoÃªlÃ©e crÃ©ole (variantes)

## Tags (IA)
`feuille` `potager` `recette` `trad`

