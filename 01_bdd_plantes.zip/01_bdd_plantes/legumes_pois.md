﻿# Légumineuses & pois

## Pois d’Angole
- Rôle sol : fixation azote / drainage
- Usage : alimentaire
- Saison : fin d’année

## Pois Congo
- Rôle sol : structuration
- Usage : alimentaire

## Pois d’œil noir
- Rôle sol : enrichissement
- Usage : alimentaire

## Pois bois
- Rôle sol : sol vivant
- Usage : alimentaire
