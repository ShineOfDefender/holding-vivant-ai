﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Tabac (Nicotiana tabacum)

**Slug IA :** `tabac`

**DisponibilitÃ© Martinique :** Possible (selon rÃ©glementation)

**Famille :** Solanaceae

**Strates :** culture_plein_soleil

**Parties utilisÃ©es :** feuilles

**Formes :** feuille_sechee

## Placement / rÃ´le
- Parcelle dÃ©diÃ©e plein soleil, rotation stricte
- Isoler des cultures alimentaires

## Notes
- Ã€ cadrer juridiquement/rÃ©glementairement avant monÃ©tisation.
- Conserver en base pour rotation/rituel, pas axe principal.

## Tags (IA)
`rotation` `plein_soleil` `feuille` `reglementation`

