﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
Plantes florales intégrées au jardin créole :
- Hibiscus rouge
- Hibiscus jaune
- Ixora
- Bougainvillier
- Chrysanthème

Usages :
- Ornement
- Rituels
- Composition florale
- Protection paysagère (haies, séparation)

