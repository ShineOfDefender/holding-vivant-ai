﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — BDD plantes  
---

# Mangue Igérie (luxe)

## Catégorie
fruitier_luxe

## Zones (Martinique)
- sèche / intermédiaire / humide / littorale (à préciser)

## Architecture jardin créole (rappel)
- Strate haute : fruitier structurant
- Sous-étage : aloe / couvre-sol selon zone
- Bordures : vétiver / légumineuses (selon objectif)

## Transformation
Positionnement premium

## Rungis
Allée cible : Produits frais (chaine du froid potentielle)

## Notes terrain
- lat/lon zones prospères à renseigner dans la matrice
