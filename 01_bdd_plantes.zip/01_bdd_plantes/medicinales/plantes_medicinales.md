﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
Plantes médicinales clés :
- Gros thym
- Petit thym
- Atoumo
- Neem
- Herbe couresse

Formes privilégiées :
- Feuilles entières
- Macération
- Poudre (cas spécifiques : neem)

Principe :
- Respect de l’intégrité végétale
- Transformation douce

