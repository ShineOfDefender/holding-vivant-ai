﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Vanille (Vanilla planifolia)

**Slug IA :** `vanille`

**DisponibilitÃ© Martinique :** Bonne (si conduite maÃ®trisÃ©e)

**Famille :** Orchidaceae

**Strates :** liane_epiphyte

**Parties utilisÃ©es :** gousses

**Formes :** gousse, extrait, poudre

## Placement / rÃ´le
- Mi-ombre : tuteurs/treillis dÃ©diÃ©s, ventilation + hygiÃ¨ne; proche passage (suivi/pollinisation)

## Tags (IA)
`luxe` `micro_lot` `long_cycle` `cure`

