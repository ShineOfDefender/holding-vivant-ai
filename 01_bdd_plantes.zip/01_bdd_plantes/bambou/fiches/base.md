﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Bambou (Bambusoideae (espÃ¨ce Ã  prÃ©ciser))

**Slug IA :** `bambou`

**DisponibilitÃ© Martinique :** Courant (selon espÃ¨ces)

**Famille :** Poaceae

**Strates :** structure_aerienne, brise_vent, stabilisation

**Parties utilisÃ©es :** chaumes, feuilles

**Formes :** tuteur, structure, materiau

**RÃ´le systÃ¨me :** Structure aÃ©rienne + tuteurs + postes de gardiens + stabilisateur du sol.

## Placement / rÃ´le (jardin crÃ©ole)
- PÃ©riphÃ©rie / lignes structurantes (brise-vent, marquage)
- Zones Ã  stabiliser (pentes, limites, bords de ravines) â€” attention Ã  la maÃ®trise des rhizomes

## Transformation / produits
- Tuteurs (vanille, lianes, jeunes arbres)
- Petites structures (clÃ´tures, pergolas lÃ©gÃ¨res, postes)
- Paillage (feuilles) si maÃ®trisÃ©

## Notes
- Choisir des bambous non envahissants ou gÃ©rer barriÃ¨re anti-rhizomes.
- Ã€ prÃ©ciser : espÃ¨ce exacte plantÃ©e / objectif (structure vs artisanat).

## Tags (IA)
`aerien` `tuteur` `postes` `anti_erosion` `biomat`

