﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Citronnelle (Cymbopogon citratus)

**Slug IA :** `citronnelle`

**DisponibilitÃ© Martinique :** TrÃ¨s Ã©levÃ©e

**Famille :** Poaceae

**Strates :** bordure_aromatique

**Parties utilisÃ©es :** feuilles

**Formes :** dried, infusion

## Placement / rÃ´le
- Bordures lumineuses, coupe rÃ©guliÃ¨re, Ã©viter concurrence sous gros arbres

## Tags (IA)
`fonctionnel` `desodorisation` `repulsif_doux` `volume`

## Ressources / Transformes (systeme)
Transformes recommandes:
- boudin_citronnelle

Notes:
- Paillage: collet degage, pas de couche humide epaisse
- Eviter zones d'arbres a latex comme noyau productif

