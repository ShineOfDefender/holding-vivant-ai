﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — BDD plantes  
---

# Bougainvillier

## Catégorie
florale_ornementale

## Rôles
- structure paysagere / brise-vue

## Parties utilisées
- À compléter

## Zones (Martinique)
- sèche / intermédiaire / humide / littorale (à préciser)

## Statut
Fiche structurée (v1)
