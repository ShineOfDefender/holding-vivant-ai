﻿# Sol & entretien — Bougainvillier

## Entretien
- Arrosage : selon zone
- Taille : selon besoin
- Protection : couvre-sol, paillage

## Techniques douces
- Infusions sol (moringa/neem) : selon compatibilité et tests
