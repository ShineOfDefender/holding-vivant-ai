﻿# Notes — Bougainvillier
- Observations terrain :
- Variétés locales :
- Sources / références :
