﻿# Plantes de service du sol

- Vétiver (drainage, stabilisation)
- Citronnelle
- Herbe couresse
- Pourpier
- Gros thym
- Petit thym
- Romarin
