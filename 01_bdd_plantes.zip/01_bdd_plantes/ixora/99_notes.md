﻿# Notes — Ixora
- Observations terrain :
- Variétés locales :
- Sources / références :
