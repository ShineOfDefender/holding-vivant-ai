﻿# Architecture jardin créole — Ixora

## Placement (strates)
- Canopée / sous-canopée / sous-bois / couvre-sol (à préciser)

## Associations recommandées
- Diversité obligatoire, éviter monoculture
- Couvrir le sol (paillage / couvre-sol)

## À éviter
- Sol nu
- Monoculture
