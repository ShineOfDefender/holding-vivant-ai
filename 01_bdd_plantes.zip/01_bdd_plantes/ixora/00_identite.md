﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — BDD plantes  
---

# Ixora

## Catégorie
florale_ornementale

## Rôles
- ornement / masse florale

## Parties utilisées
- À compléter

## Zones (Martinique)
- sèche / intermédiaire / humide / littorale (à préciser)

## Statut
Fiche structurée (v1)
