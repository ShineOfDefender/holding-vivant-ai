﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
Plantes utilitaires :
- Bambou (structures, abris)
- Vétiver (stabilisation)
- Neem (poudres, répulsif)

Fonction :
- Architecture vivante
- Protection naturelle
- Sécurité douce

