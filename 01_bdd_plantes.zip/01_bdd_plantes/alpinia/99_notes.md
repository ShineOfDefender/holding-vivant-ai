﻿# Notes — Alpinia
- Observations terrain :
- Variétés locales :
- Sources / références :
