﻿# Index — Base de données plantes HOLDING_VIVANT

- Arbres & épices
- Légumineuses & pois
- Florales & ornementales
- Vivriers structurants
- Plantes de service du sol
