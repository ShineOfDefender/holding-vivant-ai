﻿# Rungis — Clou de girofle (Syzygium aromaticum)

## Allée cible
Épicerie sèche élargie (épices & légumineuses)

## Différenciation
- origine Caraïbe
- traçabilité
- transformation locale

## Formats
- vrac pro
- sacs
- conditionnement institutionnel
