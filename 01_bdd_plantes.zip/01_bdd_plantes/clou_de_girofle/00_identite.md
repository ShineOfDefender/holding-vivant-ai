﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — BDD plantes  
---

# Clou de girofle (Syzygium aromaticum)

## Catégorie
arbre_epice

## Rôles
- Épice / aromatique (selon espèce)
- Structure long terme du jardin créole
- Valeur patrimoniale et commerciale

## Parties utilisées
- À compléter (graines, feuilles, etc.)

## Risques / précautions
- À compléter

## Statut
Fiche structurée (v1)
