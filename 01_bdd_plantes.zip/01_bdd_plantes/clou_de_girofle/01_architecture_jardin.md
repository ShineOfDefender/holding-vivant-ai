﻿# Architecture jardin créole — Clou de girofle (Syzygium aromaticum)

## Zone(s) favorables (Martinique)
- À préciser : (sèche / intermédiaire / humide / littorale)

## Placement recommandé (strates)
- Canopée / sous-canopée : arbre structurant
- Sous-étage recommandé : couvre-sol + plantes de service (ex : vétiver en bordure)

## Associations recommandées
- Légumineuses (amélioration sol)
- Couvrir le sol pour limiter évaporation
- Éviter monoculture

## À éviter
- Exposition / vent / sol (à préciser)
- Compétition racinaire non maîtrisée
