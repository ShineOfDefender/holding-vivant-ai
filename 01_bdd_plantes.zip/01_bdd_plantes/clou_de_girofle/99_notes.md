﻿# Notes — Clou de girofle (Syzygium aromaticum)
- Observations terrain :
- Variétés locales :
- Sources / références :
