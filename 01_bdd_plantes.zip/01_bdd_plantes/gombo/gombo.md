﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Gombo — fiche plante

## Usages alimentaires
- Gousses consommées cuites
- Feuilles consommables
- Effet émollient digestif

## Usages cosmétiques
- Extraction du mucilage
- Gel hydratant cheveux
- Définition et gainage naturel

## Transformation
- Extraction aqueuse douce
- Aucun broyage fin
- Utilisation fraîche ou stabilisée

## Statut stratégique
Plante pivot alimentaire + cosmétique.

