﻿# Fiche Base — Gombo (Abelmoschus esculentus)

**Slug IA :** gombo

## Profil (scalable & vendable)
**Rôle système :** Légume productif (cycle court) + forte demande cuisine.

**Formes vendables (MVP) :**
- Frais calibré
- Tranché (phase 2)
- Séché (phase 2 si marché)

**Tags (IA) :**
scalable cycle_court cuisine egularite humide_mixte

## Zones cibles
- Humide → mixte : OK si drainage correct
- Éviter stagnation d’eau (maladies)
