﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fleur de gombo — usage floral

## Description
Fleur jaune pâle à cœur rouge, type hibiscus.
Floraison éphémère (cycle court).

## Usages recommandés
- Jardins créoles vivants
- Parcours botaniques
- Jardins thérapeutiques (EHPAD, hôpitaux)
- Compositions rituelles et symboliques

## Usages non recommandés
- Bouquets longue durée
- Transport longue distance
- Fleuristerie industrielle

## Rôle
Valorisation paysagère et foncière par le vivant.

