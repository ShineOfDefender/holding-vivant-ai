﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — BDD plantes  
---

# Petit thym

## Catégorie
plante_service_sol

## Rôles
- aromatique / jardin creole

## Parties utilisées
- À compléter

## Zones (Martinique)
- sèche / intermédiaire / humide / littorale (à préciser)

## Statut
Fiche structurée (v1)
