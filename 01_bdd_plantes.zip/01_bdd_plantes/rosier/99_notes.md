﻿# Notes — Rosier
- Observations terrain :
- Variétés locales :
- Sources / références :
