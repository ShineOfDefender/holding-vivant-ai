﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — BDD plantes  
---

# Rosier

## Catégorie
florale_ornementale

## Rôles
- usage sobre / universel

## Parties utilisées
- À compléter

## Zones (Martinique)
- sèche / intermédiaire / humide / littorale (à préciser)

## Statut
Fiche structurée (v1)
