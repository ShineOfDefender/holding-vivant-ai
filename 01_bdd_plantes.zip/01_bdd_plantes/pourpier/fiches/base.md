﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Pourpier (Portulaca oleracea)

**Slug IA :** `pourpier`

**DisponibilitÃ© Martinique :** TrÃ¨s courant

**Famille :** Portulacaceae

**Strates :** couvre_sol_potager

**Parties utilisÃ©es :** feuilles, tiges

**Formes :** fresh, salade

**RÃ´le systÃ¨me :** Couvre-sol comestible + potager (rÃ©silience).

## Placement / rÃ´le (jardin crÃ©ole)
- Bord de planches, zones sÃ¨ches, proche cuisine

## Tags (IA)
`couvre_sol` `potager` `facile`

