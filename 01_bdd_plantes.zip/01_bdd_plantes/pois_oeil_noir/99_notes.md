﻿# Notes — Pois d’œil noir
- Observations terrain :
- Variétés locales :
- Sources / références :
