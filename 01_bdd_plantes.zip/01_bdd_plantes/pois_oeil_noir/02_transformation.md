﻿# Transformation — Pois d’œil noir

## Produits possibles
- Sec / frais / poudre / infusion (à préciser)

## Procédés (principes)
- Séchage doux si applicable
- Traçabilité par lot
- Valorisation des rejets

