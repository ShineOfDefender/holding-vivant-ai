﻿# Rungis — Pois d’œil noir

## Allée cible
Epicerie seche elargie

## Formats
- vrac pro
- conditionnement institutionnel

## Différenciation
- local
- traçable
- transformation maîtrisée
