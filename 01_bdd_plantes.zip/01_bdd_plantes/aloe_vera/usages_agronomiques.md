﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Aloe vera — usages agronomiques observés

## Constat terrain
L’aloe vera appliqué directement sur certaines plaies ou zones sensibles des arbres :
- crée un **film protecteur naturel**,
- limite les agressions extérieures,
- favorise la cicatrisation,
- tout en **asséchant progressivement la plante d’aloe utilisée**.

Cette pratique est issue de l’observation et de l’expérimentation terrain.

---

## Espèces réceptives (observations)
- Prune citerne : réponse très favorable, redemande observable
- Arbres fruitiers (général) : effet protecteur notable

## Espèces non compatibles
- Rose du désert (Adenium) : réaction défavorable observée  
→ ne pas utiliser d’aloe sur cette espèce

---

## Hypothèse fonctionnelle
- Film végétal protecteur
- Effet antiseptique léger
- Transfert d’humidité et de composés actifs

---

## Statut
- Savoir-faire empirique documenté
- À tester, confirmer et affiner
- Usage interne HOLDING_VIVANT

