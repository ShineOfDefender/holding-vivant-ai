﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# protocoles

_Ã€ complÃ©ter (sÃ©chage, stockage, conditionnement)._ 

