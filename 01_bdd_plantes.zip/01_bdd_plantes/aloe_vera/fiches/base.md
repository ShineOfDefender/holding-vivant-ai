﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” AloÃ¨s (Aloe vera)

**Slug IA :** `aloe_vera`

**DisponibilitÃ© Martinique :** TrÃ¨s Ã©levÃ©e

**Famille :** Asphodelaceae

**Strates :** couvre_sol_sec

**Parties utilisÃ©es :** feuilles

**Formes :** gel, dried, powder, fresh

## Placement / rÃ´le
- Sous manguier (ombre claire), collet dÃ©gagÃ©, pierres en surface
- Arc interne du quart de cercle : zone sÃ¨che et drainÃ©e

## Tags (IA)
`cutane` `apaisant` `neutre` `stable` `institution`

## Ressources / Transformes (systeme)
Transformes recommandes:
- paillage_manguier_sec
- arc_pierres_frontiere

Notes:
- Paillage: collet degage, pas de couche humide epaisse
- Eviter zones d'arbres a latex comme noyau productif

