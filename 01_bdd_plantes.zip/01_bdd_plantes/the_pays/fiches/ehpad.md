﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche EHPAD â€” ThÃ© pays (concept)

_Ã€ complÃ©ter (canal non dÃ©fini pour cette plante)._ 

