﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” ThÃ© pays (concept) (Mix dâ€™infusions locales (ex: atoumo, citronnelle, autres))

**Slug IA :** `the_pays`

**DisponibilitÃ© Martinique :** TrÃ¨s courant

**Famille :** Mix

**Strates :** aromatiques

**Parties utilisÃ©es :** feuilles

**Formes :** dried, infusion, melange

## Placement / rÃ´le
- CrÃ©er des bandes infusion dÃ©diÃ©es, proches des chemins (rÃ©colte + sÃ©chage rapide)

## Notes
- On documente le mÃ©lange exact dans un futur fichier recette/lot.

## Tags (IA)
`infusion` `patrimoine` `melange`

