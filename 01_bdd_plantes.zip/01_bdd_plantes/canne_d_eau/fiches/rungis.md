﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche RUNGIS â€” Canne dâ€™eau (terme local)

_Ã€ complÃ©ter (canal non dÃ©fini pour cette plante)._ 

