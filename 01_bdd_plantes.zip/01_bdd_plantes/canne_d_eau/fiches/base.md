﻿**Fondateur & architecte du projet : Nicolas BLEDIN**  
HOLDING_VIVANT — Document interne  
---
# Fiche Base â€” Canne dâ€™eau (terme local) (Ã€ prÃ©ciser (terme local : espÃ¨ce exacte Ã  identifier))

**Slug IA :** `canne_d_eau`

**DisponibilitÃ© Martinique :** PrÃ©sente selon zones

**Famille :** Ã€ prÃ©ciser

**Strates :** zone_humide_tampon

**Parties utilisÃ©es :** tiges, feuilles

**Formes :** n/a

## Placement / rÃ´le
- Zones tampons humides / limites de ruissellement (si utilisÃ©e comme rÃ©gulateur dâ€™eau)
- Ne pas mÃ©langer avec canne AOC sans plan de drainage

## Notes
- On la garde comme Ã©lÃ©ment dâ€™architecture hydrique.
- Pour la botanique exacte : une photo + nom local prÃ©cis et on fixe lâ€™espÃ¨ce.

## Tags (IA)
`tampon_humide` `anti_inondation` `drainage`

