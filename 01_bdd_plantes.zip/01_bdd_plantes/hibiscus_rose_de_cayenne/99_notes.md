﻿# Notes — Hibiscus / Rose de Cayenne
- Observations terrain :
- Variétés locales :
- Sources / références :
